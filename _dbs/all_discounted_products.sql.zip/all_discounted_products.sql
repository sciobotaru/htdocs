-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 13, 2018 at 11:54 PM
-- Server version: 5.6.39-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asigurat_electrodeals`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_discounted_products`
--

CREATE TABLE `all_discounted_products` (
  `ProductIndex` int(11) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `ProductTitle` varchar(150) NOT NULL,
  `Vendor` varchar(20) NOT NULL,
  `OldPrice` varchar(10) NOT NULL,
  `NewPrice` varchar(10) NOT NULL,
  `Discount` varchar(10) NOT NULL,
  `LinkToProduct` varchar(300) NOT NULL,
  `LinkToPictureThumbnail` varchar(300) NOT NULL,
  `StockStatus` varchar(30) CHARACTER SET ucs2 COLLATE ucs2_romanian_ci NOT NULL,
  `Rating` varchar(5) NOT NULL,
  `NumberOfReviews` varchar(5) NOT NULL,
  `NewPriceValue` int(11) NOT NULL,
  `DiscountValue` int(11) NOT NULL,
  `PriceCategory` varchar(20) NOT NULL,
  `HotLevel` varchar(2) NOT NULL,
  `ProductID` varchar(50) NOT NULL,
  `LinkYoutube` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_discounted_products`
--

INSERT INTO `all_discounted_products` (`ProductIndex`, `Category`, `ProductTitle`, `Vendor`, `OldPrice`, `NewPrice`, `Discount`, `LinkToProduct`, `LinkToPictureThumbnail`, `StockStatus`, `Rating`, `NumberOfReviews`, `NewPriceValue`, `DiscountValue`, `PriceCategory`, `HotLevel`, `ProductID`, `LinkYoutube`) VALUES
(0, 'Telefoane Mobile', 'HTC U 11 Dual-Sim Brilliant Black', 'Germanos', '3.299,00', '1.999,00', '-39%', 'http://www.germanos.ro/htc-u-11-dual-sim-brilliant-black--117883/?categoryId=1831', 'http://d2i7s9ebeushcy.cloudfront.net/res/product_200/78deeabc-4f0b-435c-a878-311920f06470.jpg', 'In stoc', '0', '0', 199900, 39, '1.000 - 2.000 Lei', '0', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_discounted_products`
--
ALTER TABLE `all_discounted_products`
  ADD PRIMARY KEY (`ProductIndex`),
  ADD KEY `ProductIndex` (`ProductIndex`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
